package com.team.NewLearn.controller.lecture;

import com.team.NewLearn.service.lecture.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class VideoController {

    @Autowired
    VideoService videoService;

    @PostMapping("/api/v1/upload")
    @ResponseBody
    public String uploadImage(@RequestParam("files") MultipartFile file) throws Exception { //multipart/form-data 요청을 받도록 컨트롤러 단에서 처리하는 로직
        System.out.println("FileUploadController!!!!!");
        return videoService.uploadVideo(file);
    }

    @GetMapping("/unit/{id}/{originId}")
    public String goToDetailLecture(Model model,@PathVariable("id") int id,@PathVariable("originId") int originId){
        int count = videoService.checkUnit(id);
        if (count > 0 ) {
            model.addAttribute("unit",videoService.getLectureUnit(id));
        } else{
            model.addAttribute("unit",videoService.getLectureUnit(originId));
        }
        return "lecture/video";
    }

}
