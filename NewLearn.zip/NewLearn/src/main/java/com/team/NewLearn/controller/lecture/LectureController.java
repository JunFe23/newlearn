package com.team.NewLearn.controller.lecture;

import com.team.NewLearn.service.lecture.LectureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LectureController {

    @Autowired
    LectureService service;

    @RequestMapping("/lecturelist")
    public String goToList(Model model){
        model.addAttribute("lectureDTOs",service.getLectureList());
        return "lecture/list.html";
    }

    @GetMapping("/detail/{id}")
    public String goToDetail(Model model,@PathVariable("id") int id){
        model.addAttribute("lectureDTO",service.getLecture(id));
        model.addAttribute("lectureUnitDTOs", service.getLectureUnit(id));
        return "lecture/detail";
    }

}
