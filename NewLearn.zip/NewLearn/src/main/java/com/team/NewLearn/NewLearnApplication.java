package com.team.NewLearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewLearnApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewLearnApplication.class, args);
	}

}
